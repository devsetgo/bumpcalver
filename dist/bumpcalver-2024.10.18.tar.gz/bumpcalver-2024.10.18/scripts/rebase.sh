#!/bin/bash
set -e
set -x

# run dev
git rebase origin/main
